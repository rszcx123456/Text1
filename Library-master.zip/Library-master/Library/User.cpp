#include <iostream>
#include "User.h"
using std::cout;
User::User()
{
}


User::~User()
{
}

