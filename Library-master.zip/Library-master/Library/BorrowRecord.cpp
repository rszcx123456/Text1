#include "BorrowRecord.h"


BorrowRecord::BorrowRecord()
{
}


BorrowRecord::~BorrowRecord()
{
}
